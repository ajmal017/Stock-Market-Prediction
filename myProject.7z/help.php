<?php
if(isset($_POST['form1'])
{ 
$topic=$_POST['form1'];
echo $topic;
}
?>